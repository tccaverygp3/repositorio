var btnSignup = document.querySelector("#signup");
var btnSignin = document.querySelector("#signin");

var body = document.querySelector("body");



btnSignup.addEventListener("click", function () {
    body.className = "sign-up-js";
})

btnSignin.addEventListener("click", function () {
body.className = "sign-in-js"; 
});

//Mostrar e esconder Senha//
function mostrarSenha_adm(){
    var inputPass = document.getElementById('senha_adm')
    var btnShowPass = document.getElementById('btn-senha_adm')}

    if (inputPass.type === 'password'){
        inputPass.setAttribute('type', 'text')
        btnShowPass.classList.replace('bi-eye-fill', 'bi-eye-slash-fill')
    }else{
        inputPass.setAttribute('type', 'password')
        btnShowPass.classList.replace('bi-eye-slash-fill', 'bi-eye-fill')
    }